<nav class="navbar navbar-expand-sm navbar-dark bg-dark fixed-top">

  <div class="container-fluid">

    <a class="navbar-brand" href="signup">
        <img src="https://r.mobirisesite.com/757077/assets/images/gd988c37b5856e2e59bc61db248bd-h_m1ue2up7.png" alt="Logo" style="width:60px;" class="rounded-pill">&nbsp;&nbsp;<b id="vce">Contacts Viewer</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mynavbar">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link" href="HomePage" id="hide">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="https://portfolio.vcequestionpapers.xyz/">Developer</a>
        <li class="nav-item">
          <a class="nav-link" href="logout.php" style="color:#7FFFD4;">Logout</a>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="text" placeholder="Search">
        <button class="btn btn-primary" type="button">Search</button>
      </form>
    </div>
  </div>
</nav>