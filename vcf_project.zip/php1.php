<?php
$a=2;
$b=3;
if($a>$b && 1||1)
print "ok";
else
print "okok";
?>