<?php
// Include config file
require_once "connect_database.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$email="";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
$username = trim($_POST["username"]);
$password=trim($_POST["password"]);
$sql = "SELECT username,password,email FROM Myusers WHERE username ='$username'";
$result = $conn->query($sql);
if ($result->num_rows==1) {
  // output data of each row
  $row = $result->fetch_assoc();
  $email=$row["email"];
  if($row["password"]==$password)
  {
                session_start();            
                            // Store data in session variables
                            $_SESSION["logged_in"] = true;
                            $_SESSION["username"] = $username;
                            if($email=="bunnyrajender55@gmail.com")
                            {
                                 echo "<!DOCTYPE html>
                    <html lang='en'>
                    <head>
                    <meta name='viewport' content='width=device-width, initial-scale=1'>
                    <link rel='icon' href='https://r.mobirisesite.com/757077/assets/images/gd988c37b5856e2e59bc61db248bd-h_m1ue2up7.png' type='image/x-icon'>
                    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.10.4/dist/sweetalert2.all.min.js
'></script>
<link href='https://cdn.jsdelivr.net/npm/sweetalert2@11.10.4/dist/sweetalert2.min.css
' rel='stylesheet'>
<style>
</style>
</head>
<body style='background-color:black;'>
<script>
const Toast = Swal.mixin({
  toast: true,
  position: 'center',
  showConfirmButton: false,
  timer: 1000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.onmouseenter = Swal.stopTimer;
    toast.onmouseleave = Swal.resumeTimer;
  }
});
Toast.fire({
  icon: 'success',
  title: 'Uploader login successful...',
}).then(function() {
    window.location='upload';
});
</script></body></html>";
                            }
                        else if($username=="myusers55")
                        {
                            header("location:New20users");
                        }
                        else if($username=="QPapers55")
                        {
                            header("location:uploadedpapers");
                        }
                        else
                        {
                          $_SESSION["user_email_id"] = $email;
                            echo "<!DOCTYPE html>
                    <html lang='en'>
                    <head>
                    <meta name='viewport' content='width=device-width, initial-scale=1'>
                    <link rel='icon' href='https://r.mobirisesite.com/757077/assets/images/gd988c37b5856e2e59bc61db248bd-h_m1ue2up7.png' type='image/x-icon'>
                    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.10.4/dist/sweetalert2.all.min.js
'></script>
<link href='https://cdn.jsdelivr.net/npm/sweetalert2@11.10.4/dist/sweetalert2.min.css
' rel='stylesheet'>
</head>
<body style='background-color:black;'>
<script>
const Toast = Swal.mixin({
  toast: true,
  position: 'center',
  showConfirmButton: false,
  timer: 1000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.onmouseenter = Swal.stopTimer;
    toast.onmouseleave = Swal.resumeTimer;
  }
});
Toast.fire({
  icon: 'success',
  title: 'Retriever login successful...',
}).then(function() {
    window.location='retrieve';
});
</script></body></html>";

                        }
  }
  else {
echo "<!DOCTYPE html>
                    <html lang='en'>
                    <head>
                    <meta name='viewport' content='width=device-width, initial-scale=1'>
                    <link rel='icon' href='https://r.mobirisesite.com/757077/assets/images/gd988c37b5856e2e59bc61db248bd-h_m1ue2up7.png' type='image/x-icon'>
                    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.10.4/dist/sweetalert2.all.min.js
'></script>
<link href='https://cdn.jsdelivr.net/npm/sweetalert2@11.10.4/dist/sweetalert2.min.css
' rel='stylesheet'>
</head>
<body>
<script>
swal.fire({
title:'Oops...',
text:'Incorrect Password For This Username...',
icon:'error',
}).then(function() {
    history.back();
});
</script></body></html>";
  }
}
else{
    echo "<!DOCTYPE html>
                    <html lang='en'>
                    <head>
                    <meta name='viewport' content='width=device-width, initial-scale=1'>
                    <link rel='icon' href='https://r.mobirisesite.com/757077/assets/images/gd988c37b5856e2e59bc61db248bd-h_m1ue2up7.png' type='image/x-icon'>
                    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.10.4/dist/sweetalert2.all.min.js
'></script>
<link href='https://cdn.jsdelivr.net/npm/sweetalert2@11.10.4/dist/sweetalert2.min.css
' rel='stylesheet'>
</head>
<body>
<script>
swal.fire({
title:'Username Does Not Exist...',
text:'Go And Signup To Create An Account...',
icon:'warning',
}).then(function() {
    history.back();
});
</script></body></html>";
}
$conn->close();
}
?>